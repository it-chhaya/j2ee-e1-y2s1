package co.istad.jdbc.dao;

import co.istad.jdbc.config.DatabaseConfig;
import co.istad.jdbc.model.Product;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductDaoImpl implements ProductDao {

    private final Connection conn;

    public ProductDaoImpl() {
        conn = DatabaseConfig.getConn();
    }

    @Override
    public List<Product> findAll() throws SQLException {

        Statement stmt = conn.createStatement();

        String sql = """
                SELECT *
                FROM products
                """;

        ResultSet rs = stmt.executeQuery(sql);
        List<Product> products = new ArrayList<>();
        while(rs.next()) {
            Product product = new Product();
            product.setId(rs.getInt("id"));
            product.setCode(rs.getString("code"));
            product.setName(rs.getString("name"));
            product.setPrice(rs.getBigDecimal("price"));
            product.setQty(rs.getInt("qty"));
            product.setStatus(rs.getBoolean("status"));

            products.add(product);
        }

        return products;
    }

}
