package co.istad.jdbc.service;

public interface ProductService {



}
