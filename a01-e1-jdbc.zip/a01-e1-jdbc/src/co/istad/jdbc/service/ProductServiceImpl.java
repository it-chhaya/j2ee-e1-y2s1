package co.istad.jdbc.service;

public class ProductServiceImpl implements ProductService {
}
