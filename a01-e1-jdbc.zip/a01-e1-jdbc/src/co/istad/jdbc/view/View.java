package co.istad.jdbc.view;

import org.nocrala.tools.texttablefmt.BorderStyle;
import org.nocrala.tools.texttablefmt.CellStyle;
import org.nocrala.tools.texttablefmt.Table;

public class View {
    public static void printMenu() {
        Table table = new Table(1, BorderStyle.UNICODE_BOX_WIDE);
        CellStyle cellStyle = new CellStyle(CellStyle.HorizontalAlign.center);
        table.addCell("App Menu", cellStyle);
        table.addCell("1) Read  2) Create  3) Update  4) Delete", cellStyle);
        table.addCell("5) Search  6) Read by Code  0) Exit App", cellStyle);

        table.setColumnWidth(0, 50, 100);

        System.out.println(table.render());
    }
}
