package co.istad.jdbc;

import co.istad.jdbc.config.DatabaseConfig;
import co.istad.jdbc.view.View;

import java.sql.*;
import java.util.Properties;

public class JdbcApp {
    public static void main(String[] args) {

        DatabaseConfig.init();

        // Print menu
        View.printMenu();

//        try (Statement stmt = DatabaseConfig.getConn().createStatement()) {
//
//            // Step 5: Execute SQL
//            ResultSet rs = stmt.executeQuery("""
//                SELECT * FROM products
//            """);
//
//            // Step 6: Handle ResultSet
//            while (rs.next()) {
//                System.out.println(rs.getInt("id"));
//                System.out.println(rs.getString("code"));
//                System.out.println(rs.getString("name"));
//                System.out.println(rs.getDouble("price"));
//                System.out.println(rs.getInt("qty"));
//                System.out.println(rs.getBoolean("status"));
//                System.out.println("--------------------------");
//            }
//
//            // Step 7: Close connection
//            // conn.close();
//        } catch (SQLException e) {
//            System.out.println("SQL error: " + e.getMessage());
//        }

    }
}
