package co.istad.jdbc.dao;

public class ProductDaoImpl implements ProductDao {
}
