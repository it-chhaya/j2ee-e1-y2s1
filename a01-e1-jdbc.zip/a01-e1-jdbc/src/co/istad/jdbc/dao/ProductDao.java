package co.istad.jdbc.dao;

public interface ProductDao {

    // Create

    // Read

    // Update

    // Delete

}
